/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfec.exam.main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import mfec.exam.readlog.ReadLog;


public class MFECExam {

    public static ArrayList<String> info = new ArrayList<>();
    
    static final String path = "C:\\Users\\gnence\\Documents\\Thesis 27.8.18\\About me\\4.4.19 MFEC Exam\\MFEC-Exam\\Web by React\\src"; // exam "C:\\Users\\MFEC-Exam\\Web by React\\src";
    static final String path_log = "src/Java.log";
    
    public static void main(String[] args) throws FileNotFoundException{
        ReadLog readlog = new ReadLog(path_log, path);
        readlog.genCost_jsonFile();
    }
}
